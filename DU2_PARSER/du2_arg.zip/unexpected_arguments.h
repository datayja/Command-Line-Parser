// DU2-ARG
// Pavel Lisa NPRG051 2010/2011
//


class UnexpectedArgumentsPolicy {
public:
	static const int IGNORE = 1;
	static const int ERROR = 2;
	static const int THROW_EXCEPTION = 3;
};
