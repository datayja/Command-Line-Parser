// DU2-ARG
// Pavel Lisa NPRG051 2010/2011
//


struct BadModifierPolicy {
	static const int THROW_EXCEPTION = 1;
	static const int ERROR = 2;
};
